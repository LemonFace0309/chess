#ifndef _COLOUR_ENUM_
#define _COLOUR_ENUM_

enum ColourEnum {
  White,
  Black
};
#endif
