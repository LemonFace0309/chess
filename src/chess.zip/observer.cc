#include "observer.h"
using namespace std;

Observer::~Observer() {}