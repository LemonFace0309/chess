#ifndef _PLAYER_ENUM_
#define _PLAYER_ENUM_

enum Player {
  Human,
  AI1,
  AI2,
  AI3,
};
#endif
